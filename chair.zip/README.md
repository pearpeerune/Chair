# Generative_systems
Generative Systems for Art and Design course materials
 ©2020 Dan Buzzo
 www.buzzo.com

 Examples built in C++ using openFrameworks (openframeworks.cc)

## 4 parameterize Chair

using parameters to make randomise furniture

*  Parameterize: Chair from Form+Code in Design, Art, and Architecture
 implemented in OpenFrameworks by Anthony Stellato <http://rabbitattack.com/>
updated March 2020 dan buzzo
 * For more information about Form+Code visit http://formandcode.com
 

![screenshot](screenshot-parameterizeChair.png)
